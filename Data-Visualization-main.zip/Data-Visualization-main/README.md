# Data-Visualization
Assignment for Simple Dataset Visualization

PLOT 1: Plotting two quantitative  attributes in a scatterplot

PLOT 2: Plotting two quantitative variables and a categorical variable in a scatterplot

PLOT 3: Plotting two quantitative variables in Line Chart

PLOT 4: Plotting a single variable in Histogram

PLOT 5: BoxPlot Representation

PLOT 6: Stacked BarChart.
